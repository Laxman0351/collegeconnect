import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { requireAuth } from '../middleware/auth';

const router = Router();

const RegisterSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  mobileNumber: z.string().regex(/^[0-9+\s-]{10,15}$/, 'Invalid mobile number format'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  role: z.enum(['STUDENT', 'TEACHER', 'ADMIN']).optional().default('STUDENT'),
});

const LoginSchema = z.object({
  mobileNumber: z.string().min(1, 'Mobile number is required'),
  password: z.string().min(1, 'Password is required'),
});

// Register endpoint
router.post('/register', async (req: Request, res: Response) => {
  try {
    const parseResult = RegisterSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({ error: parseResult.error.errors[0].message });
    }

    const { name, mobileNumber, password, role } = parseResult.data;

    const existingUser = await prisma.user.findUnique({
      where: { mobileNumber },
    });

    if (existingUser) {
      return res.status(409).json({ error: 'User with this mobile number already exists' });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const user = await prisma.user.create({
      data: {
        name,
        mobileNumber,
        passwordHash,
        role: role as 'STUDENT' | 'TEACHER' | 'ADMIN',
      },
      select: {
        id: true,
        name: true,
        mobileNumber: true,
        role: true,
        createdAt: true,
      },
    });

    // Set session
    req.session.userId = user.id;
    req.session.role = user.role;

    return res.status(201).json({
      message: 'Registration successful',
      user,
    });
  } catch (error) {
    console.error('Registration Error:', error);
    return res.status(500).json({ error: 'Internal server error during registration' });
  }
});

// Login endpoint
router.post('/login', async (req: Request, res: Response) => {
  try {
    const parseResult = LoginSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({ error: parseResult.error.errors[0].message });
    }

    const { mobileNumber, password } = parseResult.data;

    const user = await prisma.user.findUnique({
      where: { mobileNumber },
    });

    if (!user) {
      return res.status(401).json({ error: 'Invalid mobile number or password' });
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid mobile number or password' });
    }

    // Set session
    req.session.userId = user.id;
    req.session.role = user.role;

    return res.json({
      message: 'Login successful',
      user: {
        id: user.id,
        name: user.name,
        mobileNumber: user.mobileNumber,
        role: user.role,
        createdAt: user.createdAt,
      },
    });
  } catch (error) {
    console.error('Login Error:', error);
    return res.status(500).json({ error: 'Internal server error during login' });
  }
});

// Get current logged-in user profile
router.get('/me', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.session.userId },
      select: {
        id: true,
        name: true,
        mobileNumber: true,
        role: true,
        createdAt: true,
      },
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    return res.json({ user });
  } catch (error) {
    console.error('Profile Error:', error);
    return res.status(500).json({ error: 'Failed to fetch user session' });
  }
});

// Logout endpoint
router.post('/logout', requireAuth, (req: Request, res: Response) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: 'Could not log out. Please try again.' });
    }
    res.clearCookie('connect.sid');
    return res.json({ message: 'Logout successful' });
  });
});

export default router;
