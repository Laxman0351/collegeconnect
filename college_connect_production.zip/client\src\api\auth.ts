import axios from 'axios';
import { User, AuthResponse } from '../types/auth';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';

export const api = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true, // Send session cookies with requests
  headers: {
    'Content-Type': 'application/json',
  },
});

export const loginUser = async (mobileNumber: string, password: string): Promise<User> => {
  const response = await api.post<AuthResponse>('/auth/login', { mobileNumber, password });
  return response.data.user;
};

export const registerUser = async (
  name: string,
  mobileNumber: string,
  password: string,
  role: 'STUDENT' | 'TEACHER' | 'ADMIN' = 'STUDENT'
): Promise<User> => {
  const response = await api.post<AuthResponse>('/auth/register', {
    name,
    mobileNumber,
    password,
    role,
  });
  return response.data.user;
};

export const getCurrentUser = async (): Promise<User | null> => {
  try {
    const response = await api.get<{ user: User }>('/auth/me');
    return response.data.user;
  } catch (error) {
    return null;
  }
};

export const logoutUser = async (): Promise<void> => {
  await api.post('/auth/logout');
};
