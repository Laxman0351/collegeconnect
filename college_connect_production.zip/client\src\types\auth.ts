export interface User {
  id: string;
  name: string;
  mobileNumber: string;
  role: 'STUDENT' | 'TEACHER' | 'ADMIN';
  createdAt: string;
}

export interface AuthResponse {
  message: string;
  user: User;
}

export interface AuthError {
  error: string;
}
