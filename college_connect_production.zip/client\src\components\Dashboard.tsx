import React from 'react';
import { LogOut, User as UserIcon, BookOpen, Users, Calendar, Award, CheckCircle } from 'lucide-react';
import { User } from '../types/auth';
import { logoutUser } from '../api/auth';

interface DashboardProps {
  user: User;
  onLogout: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ user, onLogout }) => {
  const handleLogout = async () => {
    try {
      await logoutUser();
    } catch (err) {
      console.error(err);
    } finally {
      onLogout();
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col">
      {/* Top Navbar */}
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center font-bold text-white shadow-md">
              CC
            </div>
            <span className="font-bold text-lg text-white tracking-wide">College Connect</span>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3 px-3 py-1.5 rounded-full bg-slate-800 border border-slate-700">
              <UserIcon className="w-4 h-4 text-sky-400" />
              <span className="text-sm font-medium text-slate-200">{user.name}</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/30 font-semibold">
                {user.role}
              </span>
            </div>

            <button
              onClick={handleLogout}
              className="p-2 rounded-xl text-slate-400 hover:text-red-400 hover:bg-slate-800 transition-colors"
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Welcome Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-sky-600 via-indigo-600 to-purple-600 p-8 shadow-2xl">
          <div className="relative z-10 max-w-2xl">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-xs font-semibold text-sky-200 mb-4">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span>Session Authenticated via Mobile Cookie</span>
            </div>
            <h1 className="text-4xl font-extrabold text-white tracking-tight">
              Welcome back, {user.name}!
            </h1>
            <p className="mt-2 text-sky-100 text-lg">
              Registered Mobile: <span className="font-mono text-white font-semibold">{user.mobileNumber}</span>
            </p>
          </div>
        </div>

        {/* Quick Stats / Modules Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 hover:border-slate-700 transition-all">
            <div className="p-3 w-fit rounded-xl bg-sky-500/10 text-sky-400 mb-4">
              <BookOpen className="w-6 h-6" />
            </div>
            <h3 className="text-slate-400 text-sm font-medium">Enrolled Courses</h3>
            <p className="text-2xl font-bold text-white mt-1">6 Modules</p>
          </div>

          <div className="p-6 rounded-2xl glass-panel border border-slate-800 hover:border-slate-700 transition-all">
            <div className="p-3 w-fit rounded-xl bg-indigo-500/10 text-indigo-400 mb-4">
              <Calendar className="w-6 h-6" />
            </div>
            <h3 className="text-slate-400 text-sm font-medium">Upcoming Schedule</h3>
            <p className="text-2xl font-bold text-white mt-1">3 Classes Today</p>
          </div>

          <div className="p-6 rounded-2xl glass-panel border border-slate-800 hover:border-slate-700 transition-all">
            <div className="p-3 w-fit rounded-xl bg-emerald-500/10 text-emerald-400 mb-4">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="text-slate-400 text-sm font-medium">Academic Status</h3>
            <p className="text-2xl font-bold text-white mt-1">Good Standing</p>
          </div>

          <div className="p-6 rounded-2xl glass-panel border border-slate-800 hover:border-slate-700 transition-all">
            <div className="p-3 w-fit rounded-xl bg-purple-500/10 text-purple-400 mb-4">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-slate-400 text-sm font-medium">Campus Network</h3>
            <p className="text-2xl font-bold text-white mt-1">Active</p>
          </div>
        </div>
      </main>
    </div>
  );
};
